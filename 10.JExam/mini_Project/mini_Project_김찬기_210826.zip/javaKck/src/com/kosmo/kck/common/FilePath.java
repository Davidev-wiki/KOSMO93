package com.kosmo.kck.common;

public abstract class FilePath {

}
