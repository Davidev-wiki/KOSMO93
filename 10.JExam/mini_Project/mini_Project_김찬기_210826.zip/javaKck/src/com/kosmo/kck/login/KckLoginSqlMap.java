package com.kosmo.kck.login;

public abstract class KckLoginSqlMap {

}
