package com.kosmo.kck.login;

public interface KckLoginDAO {

}
