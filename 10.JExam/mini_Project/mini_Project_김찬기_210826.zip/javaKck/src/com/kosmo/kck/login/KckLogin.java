package com.kosmo.kck.login;

public class KckLogin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
